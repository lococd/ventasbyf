document.addEventListener('deviceready', function(){
  var ipServer = '10.10.128.43:8092';//'200.75.24.75:8092';

  function checkToken(token){
    if(token != '' && token !== null){
      $("#lblTexto").text('Iniciando sesión...');
      $.post("http://"+ipServer+"/authDmg/index.php/auth/checkToken/",{token:token})
      .done(function(data){
              window.location.replace("main.html");
      })
      .fail(function(data){
              $("#lblTexto").text(data.responseJSON.response);
              return;
      });
      /*$.ajax({url: "http://200.75.24.75:8092/authDmg/index.php/auth/checkToken/",
            type:"POST",
            data:{token},
            success: function(data){
              window.location.replace("main.html");
            },
            error: function(data,textstatus,errorThrown){
              $("#lblTexto").text(data.responseJSON.response);
              return;
            },
            timeout:3000
           });*/
    }
  }
  
  checkToken(localStorage.getItem("tokenDMG"));

  $("#btnLogin").click(function(e){
    var user = $("#txtUser").val();
    var password = $("#txtPassword").val();
    if(user.length>0 && password.length>0){
      $.post("http://"+ipServer+"/authDmg/",{user:user,password:password})
      .done(function(data){
                localStorage.setItem("tokenDMG", data.response);
                window.location.replace("main.html");
       })
      .fail(function(data){
              //alert("error: "+JSON.stringify(data));
              $("#lblTexto").text(data.responseJSON.response);
              $("#txtUser").val('');
              $("#txtPassword").val('');
              $("#txtUser").focus();
      });
      /*$.ajax({url: "http://200.75.24.75:8092/authDmg/",
            type:"POST",
            data:{user:user,password:password},
            success: function(data){
              //alert(JSON.stringify(data));
                localStorage.setItem("tokenDMG", data.response);
              window.location.replace("main.html");
            },
            error: function(data){
              //alert("error: "+JSON.stringify(data));
              $("#lblTexto").text(data.responseJSON.response);
              $("#txtUser").val('');
              $("#txtPassword").val('');
              $("#txtUser").focus();
            }
           });*/
    }
    else{
      $("#lblTexto").text("Ingrese usuario y contraseña");
      $("#txtUser").val('');
      $("#txtPassword").val('');
      $("#txtUser").focus();
    }
  });

}, false);