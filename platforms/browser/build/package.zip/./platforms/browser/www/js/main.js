document.addEventListener('deviceready', function(){
	var ipServer = '10.10.128.43:8092';//'200.75.24.75:8092';
	//funciones auxiliares
	function auth(token){
		if(token.length==0){
			window.location.replace("index.html");
		}
		else
		{
			checkBd();
		}
	};

	function cargarModalLpr(){
		//createDb();
		$('#modalLpr').modal('toggle');
		$("#lblTituloLpr").text('Cargando Locales...');
		getLprs(window.localStorage.getItem('tokenDMG'));
	}
	auth(window.localStorage.getItem('tokenDMG'));

	function getStock(codpro, codlocal, token){
		$("#stocklocal").text('Obteniendo Stock...');
		$("#stockCD").text('');
		$.post("http://"+ipServer+"/authDmg/index.php/stock/",{codlocal:codlocal,codpro:codpro,token:token})
		.done(function(data){
            $("#stocklocal").text("Stock local: " + data.response[0].STOCKS);
            $("#stockCD").text("Stock CD Dimeiggs: " + data.response[1].STOCKS);
		})
		.fail(function(data){
			alert("Error: "+JSON.stringify(data.responseJSON.response));
            window.location.replace("index.html");
	    });
	};

	function escanear(){
	    cordova.plugins.barcodeScanner.scan(
	      function (result) {
	          if (result.cancelled == false){
	            getPrecio(parseInt(result.text),0);
	          }
	      },
	      function (error) {
	          alert("Error: " + error);
	      },
	      {
	          preferFrontCamera : false, // iOS and Android
	          showTorchButton : true, // iOS and Android
	          torchOn: false, // Android, launch with the torch switched on (if available)
	          prompt : "Acerque un código de barras al área de detección", // Android
	          resultDisplayDuration: 0, // Android, display scanned text for X ms. 0 suppresses it entirely, default 1500
	          formats : "EAN_13,CODABAR", // default: all but PDF_417 and RSS_EXPANDED
	          orientation : "portrait", // Android only (portrait|landscape), default unset so it rotates with the device
	          disableAnimations : true, // iOS
	          disableSuccessBeep: false // iOS
	      }
	   );
	};

	function checkBd(){
		if(window.localStorage.getItem("nombreLocal") == null || window.localStorage.getItem("nombreLocal") == ''){
			cargarModalLpr();
			return;
		}
		window.sqlitePlugin.importPrepopulatedDatabase({file: "precios.db", "importIfExists": false});
		var db = window.sqlitePlugin.openDatabase({name: "precios.db"});
		var query = 'select count(*) as TOTAL from precios';
		db.executeSql(query, [], function(rs) {
	    if(rs.rows.item(0).TOTAL == 0){
			cargarModalLpr();
	    }
	    else{
	      $("#lblLocal").text('Local: ' + window.localStorage.getItem("nombreLocal"));
	    }
	  }, function(error) {
	  		cargarModalLpr();
	  });
	}

	

	/*function createDb(){
		var query = 'CREATE TABLE IF NOT EXISTS PRECIOS ("FECPRO","DESCRIP" , "CODPRO" , "CODLPR" , "CODLVE" , "PRECOM" INTEGER, "EAN13" )';
		var db = window.sqlitePlugin.openDatabase({name: "precios.db"});
		db.executeSql(query, [], function(rs) {
	  	}, function(error) {
	    	alert('Error en la consulta: ' + error.message);
	  	});
	}

	function cleanDb(){
		var query = 'DELETE FROM PRECIOS';
		var db = window.sqlitePlugin.openDatabase({name: "precios.db"});
		db.executeSql(query, [], function(rs) {
	  	}, function(error) {
	    	alert('Error en la consulta: ' + error.message);
	  	});
	}*/

	function getPrecio(ean13, manual){

	   var query = 'select descrip,codpro, precom from precios where codlpr = \''+window.localStorage.getItem('codlpr')+'\' and codlve = \''+window.localStorage.getItem('codlve')+'\' and codpro =\''+ean13+'\'';

	   if(ean13.toString().length == 13){
	      query = 'select descrip,codpro, precom from precios where codlpr = \''+window.localStorage.getItem('codlpr')+'\' and codlve = \''+window.localStorage.getItem('codlve')+'\' and ean13 =\''+ean13+'\'';
	   }

	   var db = window.sqlitePlugin.openDatabase({name: "precios.db"});

	   db.executeSql(query, [], function(rs) {
	    if(rs.rows.length == 0){
	      $("#descrip").text('Código '+ ean13 +' no tiene precio comercio en este local');
	      $("#codpro").text('');
	      $("#preuni").text('');
	    }
	    else{
	      $("#descrip").text('Producto: '+rs.rows.item(0).DESCRIP);
	      $("#codpro").text('Codigo: '+ rs.rows.item(0).CODPRO);
	      $("#preuni").text('Precio Unitario Comercio: $' + rs.rows.item(0).PRECOM.toLocaleString('ES-CL','currency'));
	      getStock(rs.rows.item(0).CODPRO,window.localStorage.getItem('numlocal'),window.localStorage.getItem('tokenDMG'));
	    }
	  }, function(error) {
	    alert('Error en la consulta: ' + error.message);
	  });
	};

	function getLprs(token){
		$.post("http://"+ipServer+"/authDmg/index.php/lpr/getLprs/",{token:token})
		.done(function(data){
			for (var i = data.response.length - 1; i >= 0; i--) {
              	$("#cmbLocales").append('<option data-numlocal="'+data.response[i]["NUMLOCAL"]+'" data-codlve="'+data.response[i]["CODLVE"]+'" data-codlpr="'+data.response[i]["CODLPR"]+'" data-nombre="'+data.response[i]["NOMBRE"]+'">'+data.response[i]["NOMBRE"]+'</>')
            };
            $("#lblTituloLpr").text('Selecciona local a Descargar');
            var codlpr = localStorage.getItem('codlpr');
            var codlve = localStorage.getItem('codlve');
            var nombre = localStorage.getItem('nombreLocal');
            var numlocal = localStorage.getItem('numlocal');
            if(codlpr!='' && codlve!=''){
            	$('#cmbLocales [data-numlocal="'+numlocal+'"]').prop('selected', true);
            }
		})
		.fail(function(data,textstatus,errorThrown){
			alert("Error: "+JSON.stringify(data.responseJSON.response));
            window.location.replace("index.html");
	    });
		/*$.ajax({url: "http://200.75.24.75:8092/authDmg/index.php/lpr/getLprs/",
            type:"POST",
            data:{token:token},
            success: function(data){
              for (var i = data.response.length - 1; i >= 0; i--) {
              	$("#cmbLocales").append('<option data-numlocal="'+data.response[i]["NUMLOCAL"]+'" data-codlve="'+data.response[i]["CODLVE"]+'" data-codlpr="'+data.response[i]["CODLPR"]+'" data-nombre="'+data.response[i]["NOMBRE"]+'">'+data.response[i]["NOMBRE"]+'</>')
              };
              $("#lblTituloLpr").text('Selecciona local a Descargar');
              var codlpr = localStorage.getItem('codlpr');
              var codlve = localStorage.getItem('codlve');
              var nombre = localStorage.getItem('nombreLocal');
              var numlocal = localStorage.getItem('numlocal');
              if(codlpr!='' && codlve!=''){
              	$('#cmbLocales [data-numlocal="'+numlocal+'"]').prop('selected', true);
              }
              
            },
            error: function(data){
              alert("Error: "+JSON.stringify(data.responseJSON.response));
              window.location.replace("index.html");
            }
           });*/
	};

	function getLpr(codlpr,codlve,token){
        $("#lblTituloLpr").text('Descargando Lista de precios...');
        $("#lblProgreso").show();

        var ft = new FileTransfer();
	    var uri = encodeURI("http://"+ipServer+"/authDmg/index.php/lpr/");

		var downloadPath = '/data/data/cl.dimeiggs.precios/databases/precios.db';

		ft.onprogress = function(progressEvent) {
			if (progressEvent.lengthComputable) {
				var perc = Math.floor(progressEvent.loaded / progressEvent.total * 100);
				$('#lblProgreso>div').text(perc+'% completado');
				$('#lblProgreso>div').css('width', perc+'%');
			} else {
				if($("#lblTituloLpr").text() == "") {
					$("#lblTituloLpr").text("Cargando...");
				} else {
					$("#lblTituloLpr").text($("#lblTituloLpr").text() += ".");
				}
			}
		};
							
		ft.download(uri, downloadPath, 
		function(entry) {
			$("#lblTituloLpr").text('Lista Descargada...');
            $("#lblLocal").text('Local: ' + window.localStorage.getItem("nombreLocal"));
			$('#btnCerrarModallpr').prop('disabled', false);
			$('#btnCerrarModallpr2').prop('disabled', false);
			$('#btnDescargaPrecios').prop('disabled', false);
			$('#cmbLocales').prop('disabled', false);
			$('#lblProgreso>div').css('width', 0+'%');
			$("#lblProgreso").hide();
		}, 
		function(error) {
			alert('Ratas! Algo salió mal :(...'+JSON.stringify(error));
			$('#btnCerrarModallpr').prop('disabled', false);
			$('#btnCerrarModallpr2').prop('disabled', false);
			$('#btnDescargaPrecios').prop('disabled', false);
			$('#cmbLocales').prop('disabled', false);
			$('#lblProgreso>div').css('width', 0+'%');
			$("#lblProgreso").hide();
		},false,
	    {
	        headers: {
	        	"Authorization": "Basic dGVzdHVzZXJuYW1lOnRlc3RwYXNzd29yZA==",
	            "token": token,
	            "codlve": codlve,
	            "codlpr": codlpr
	        }
	    });


        /*var db = window.sqlitePlugin.openDatabase({name: "precios.db"});
        var query;

        $.post("http://"+ipServer+"/authDmg/index.php/lpr/",{codlpr:codlpr,codlve:codlve,token:token})
		.done(function(data){
			$("#lblTituloLpr").text('Guardando Lista de precios...');
            cleanDb();
            console.log('Terminada carga AJAX: ');
            db.transaction(function(tx){
	            	$.each(data.response,function(i,item){
	            	query = "INSERT INTO precios (FECPRO, DESCRIP, CODPRO, CODLPR, CODLVE, PRECOM, EAN13) VALUES " +
					"('"+item.FECPRO+"','" +item.DESCRIP+"','"+item.CODPRO+"','"+item.CODLPR+"','"+item.CODLVE+"','"+item.PRECOM+"','"+item.EAN13+"')";
					tx.executeSql(query);
					console.log(JSON.stringify(item));
	            });
            },
            			   function(err){
            				alert(err);
            			   },
            			   function(){
            			   	$("#lblTituloLpr").text('Lista Descargada...');
            			   	$("#lblLocal").text('Local: ' + window.localStorage.getItem("nombreLocal"));
            			   });
		})
		.fail(function(data){
			alert("Error: "+JSON.stringify(data.responseJSON.response));
            window.location.replace("index.html");
	    });*/

		/*$.ajax({url: "http://200.75.24.75:8092/authDmg/index.php/lpr/",
            type:"POST",
            data:{codlpr:codlpr,codlve:codlve,token:token},
            success: function(data){
            $("#lblTituloLpr").text('Guardando Lista de precios...');
            cleanDb();
            console.log('Terminada carga AJAX: ');
            db.transaction(function(tx){
	            	$.each(data.response,function(i,item){
	            	query = "INSERT INTO precios (FECPRO, DESCRIP, CODPRO, CODLPR, CODLVE, PRECOM, EAN13) VALUES " +
					"('"+item.FECPRO+"','" +item.DESCRIP+"','"+item.CODPRO+"','"+item.CODLPR+"','"+item.CODLVE+"','"+item.PRECOM+"','"+item.EAN13+"')";
					tx.executeSql(query);
					console.log(JSON.stringify(item));
	            });
            },
            			   function(err){
            				alert(err);
            			   },
            			   function(){
            			   	$("#lblTituloLpr").text('Lista Descargada...');
            			   	$("#lblLocal").text('Local: ' + window.localStorage.getItem("nombreLocal"));
            			   });
            },
            error: function(data){
              alert("Error: "+JSON.stringify(data.responseJSON.response));
              window.location.replace("index.html");
            }
        });*/
	};

	

	//eventos de botones
	$("#btnEscanear").click(function(e){
	    escanear();
	  });

	$("#buscarProducto").click(function(e){
		var txtPro =  $("#txtPro").val();
	    if(txtPro!=''){
	      $('#modalCodpro').modal('hide');
	      getPrecio(parseInt(txtPro),1);
	      $("#txtPro").val('');
	    }
	    else{
	      alert('Ingrese un código válido');
	      $("#txtPro").val('');
		}
	});

	$("#btnCodigo").click(function (e) {
		$('#modalCodpro').modal('toggle');
		$("#txtPro").focus();
	});

	$("#btnLpr").click(function(e){
		cargarModalLpr();
	});

	$("#btnDescargaPrecios").click(function(e){
		if($('#cmbLocales').children().length>0){
			localStorage.setItem("codlpr", ($('#cmbLocales :selected').data('codlpr')));
			localStorage.setItem("nombreLocal", ($('#cmbLocales :selected').data('nombre')));
			localStorage.setItem("codlve", ($('#cmbLocales :selected').data('codlve')));
			localStorage.setItem("numlocal", ($('#cmbLocales :selected').data('numlocal')));
			$('#btnCerrarModallpr').prop('disabled', true);
			$('#btnCerrarModallpr2').prop('disabled', true);
			$('#btnDescargaPrecios').prop('disabled', true);
			$('#cmbLocales').prop('disabled', true);
			getLpr(localStorage.getItem('codlpr'), localStorage.getItem('codlve'),localStorage.getItem('tokenDMG'))
		}
		else{
			$('#localActual').text("Locales no cargados, compruebe su conexión a internet");
		}

	});

	$("#btnCerrarSesion").click(function(e){
		localStorage.setItem("tokenDMG", '');
		window.location.replace("index.html");
	});

});